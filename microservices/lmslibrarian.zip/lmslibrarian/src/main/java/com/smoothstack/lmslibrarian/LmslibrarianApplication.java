package com.smoothstack.lmslibrarian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmslibrarianApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmslibrarianApplication.class, args);
	}
}

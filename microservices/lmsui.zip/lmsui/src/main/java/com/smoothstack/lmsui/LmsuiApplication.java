package com.smoothstack.lmsui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsuiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmsuiApplication.class, args);
	}
}

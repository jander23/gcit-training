"use strict"

import React from 'react';

export class Home extends React.Component{
    render() {
        return(
            <div className="jumbotron">
                <h1>Library Management System</h1>
            </div>
        );
    }
}